"""Automatic PAPER-ONLY BTC 15m paired-contract scanner. No authenticated endpoints."""
import math
import sqlite3
from datetime import datetime, timezone
import requests
import streamlit as st

API = 'https://external-api.kalshi.com/trade-api/v2'
DB = 'auto_paper.sqlite3'
SERIES = 'KXBTC15M'
st.set_page_config(page_title='BTC15 Auto Paper Bot', page_icon='₿', layout='centered')


def api(path, params=None):
    r = requests.get(API + path, params=params, timeout=12)
    r.raise_for_status()
    return r.json()


def price(m, side):
    v = m.get(f'{side}_ask_dollars')
    if v is not None and v != '':
        return float(v)
    v = m.get(f'{side}_ask')
    return float(v) / 100 if v is not None else None


def fee(p, n):
    return math.ceil(100 * 0.07 * n * p * (1-p)) / 100


def init():
    with sqlite3.connect(DB) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS pairs (
            ticker TEXT PRIMARY KEY, yes_price REAL, no_price REAL, qty INTEGER,
            fees REAL, cost REAL, placed_at TEXT, status TEXT DEFAULT 'OPEN',
            result TEXT, pnl REAL)''')
        db.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)')
        db.execute("INSERT OR IGNORE INTO settings VALUES ('enabled','0')")
        db.execute("INSERT OR IGNORE INTO settings VALUES ('starting_balance','100')")


def setting(db, key):
    return db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()[0]


def put(db, key, value):
    db.execute('UPDATE settings SET value=? WHERE key=?', (str(value), key))


def cash(db):
    starting = float(setting(db, 'starting_balance'))
    settled = db.execute("SELECT COALESCE(SUM(pnl),0) FROM pairs WHERE status='SETTLED'").fetchone()[0]
    reserved = db.execute("SELECT COALESCE(SUM(cost),0) FROM pairs WHERE status='OPEN'").fetchone()[0]
    return starting + settled - reserved


def run_cycle():
    with sqlite3.connect(DB) as db:
        if setting(db, 'enabled') != '1':
            return 'Paused'
    markets = api('/markets', {'series_ticker': SERIES, 'status': 'open', 'limit': 100}).get('markets', [])
    count = 0
    for m in markets:
        ticker = m.get('ticker')
        if not ticker or m.get('status') != 'active':
            continue
        closing = m.get('close_time')
        if not closing:
            continue
        seconds = (datetime.fromisoformat(closing.replace('Z','+00:00')) - datetime.now(timezone.utc)).total_seconds()
        if seconds < 60 or seconds > 15 * 60 + 120:
            continue
        y, n = price(m, 'yes'), price(m, 'no')
        if y is None or n is None or not (0 < y < 1 and 0 < n < 1):
            continue
        # Both YES and NO settle to a combined $1 per pair regardless of outcome.
        # Requires BOTH offers to be actually executable; this is not checked here.
        with sqlite3.connect(DB) as db:
            if db.execute('SELECT 1 FROM pairs WHERE ticker=?', (ticker,)).fetchone():
                continue
            available = min(5.0, cash(db))  # Hard cap: $5 per market
            qty = 0
            for q in range(1, 101):
                total_fees = fee(y, q) + fee(n, q)
                total = q * (y+n) + total_fees
                if total <= available and total < q - 0.02*q:
                    qty = q
            if not qty:
                continue
            total_fees = fee(y,qty) + fee(n,qty)
            total = qty*(y+n) + total_fees
            db.execute('''INSERT OR IGNORE INTO pairs
                (ticker,yes_price,no_price,qty,fees,cost,placed_at)
                VALUES (?,?,?,?,?,?,?)''', (ticker,y,n,qty,total_fees,total,datetime.now(timezone.utc).isoformat()))
            count += 1
    # Check official settlement; no spot-price approximation.
    with sqlite3.connect(DB) as db:
        open_tickers = [x[0] for x in db.execute("SELECT ticker FROM pairs WHERE status='OPEN'")]
    for ticker in open_tickers:
        try:
            m = api('/markets/' + ticker).get('market', {})
            result = str(m.get('result') or '').lower()
            if result not in ('yes','no'):
                continue
            with sqlite3.connect(DB) as db:
                row = db.execute("SELECT qty,cost FROM pairs WHERE ticker=? AND status='OPEN'",(ticker,)).fetchone()
                if row:
                    db.execute("UPDATE pairs SET status='SETTLED', result=?, pnl=? WHERE ticker=? AND status='OPEN'", (result.upper(),row[0]-row[1],ticker))
        except (requests.RequestException, ValueError):
            continue
    return f'Scan complete: {len(markets)} markets inspected, {count} new simulated paired trades.'

init()
st.title('₿ BTC 15m — Auto Paper Bot')
st.warning('SIMULATION ONLY. No Kalshi orders are placed. This strategy requires buying BOTH YES and NO below $1 combined after estimated fees. Displayed asks may not be executable together.')
with sqlite3.connect(DB) as db:
    enabled = setting(db, 'enabled') == '1'
    balance = cash(db)
    realized = db.execute("SELECT COALESCE(SUM(pnl),0) FROM pairs WHERE status='SETTLED'").fetchone()[0]
    count = db.execute('SELECT COUNT(*) FROM pairs').fetchone()[0]
a,b,c = st.columns(3)
a.metric('Paper cash', f'${balance:.2f}')
b.metric('Realized P/L', f'${realized:+.2f}')
c.metric('Paper trades',count)
new_enabled = st.toggle('Automatic paper trading', value=enabled)
if new_enabled != enabled:
    with sqlite3.connect(DB) as db:
        put(db,'enabled',int(new_enabled))
    st.rerun()
st.caption('Checks roughly every 30 seconds while this page has an active session. To run continuously, deploy a separate scheduled background worker. Closing Safari can stop scans.')
@st.fragment(run_every='30s')
def scanner():
    with sqlite3.connect(DB) as db:
        active = setting(db,'enabled') == '1'
    if active:
        try:
            st.info(run_cycle())
        except (requests.RequestException, ValueError, KeyError) as exc:
            st.error(f'API scan failed: {exc}')
    else:
        st.info('Automatic trading is paused.')
scanner()
if st.button('Refresh trade history'):
    st.rerun()
with sqlite3.connect(DB) as db:
    rows = db.execute('SELECT ticker,qty,yes_price,no_price,cost,status,result,pnl,placed_at FROM pairs ORDER BY placed_at DESC LIMIT 100').fetchall()
if rows:
    st.dataframe([dict(zip(['Market','Pairs','YES ask','NO ask','Total cost','Status','Official result','P/L','Time UTC'],r)) for r in rows],use_container_width=True,hide_index=True)
else:
    st.caption('No simulated trades yet. Most markets will not offer a risk-free paired discount at displayed asks.')
st.caption('Fees use an illustrative formula. No liquidity checks, order-book depth, or fill synchronization. Do not use this logic for real-money execution.')
