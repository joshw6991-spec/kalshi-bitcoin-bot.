# Kalshi BTC 15-Minute Paper Bot — Version 1

A local Streamlit dashboard for the `KXBTC15M` Kalshi series, with market discovery, displayed YES/NO asks, manually supplied probability estimates, a simulated trade journal, and manual official-result settlement.

## Start

Install Python 3.10+ and run:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open the local URL printed by Streamlit. To view on your phone on the same Wi-Fi, run `python -m streamlit run app.py --server.address 0.0.0.0` and visit the computer's local IP address on port 8501. **Do not expose this unprotected server to the public Internet.**

## Important limitations

- Paper trading only; there is **no live order execution code** in this release.
- Quotes come from Kalshi public REST API and may be stale, unavailable, or subject to changes in response format.
- Estimates rely on a probability **you supply**. No predictive model or backtest is implemented yet.
- Fee estimates use the general taker formula, not an authoritative fee quote for the market.
- Simulated trades assume fills at displayed ask and can overstate achievable results.
- Manual settlement must use Kalshi's official market result. There is no automatic settlement or reconciliation.
- The bankroll input is a starting balance and is not persisted as an account setting.

## Before considering real trading

Add and test a properly calibrated independent probability model, verified Kalshi fee schedules, executable depth-based pricing, live quote freshness checks, official settlement reconciliation, loss limits, authentication, idempotency, kill switch, and an explicit separate opt-in to real orders. Never put API private keys into the dashboard or a shared repository.

API docs: https://docs.kalshi.com/api-reference

## Automatic paper trading (iPhone-compatible web dashboard)

Launch `streamlit run auto_app.py` instead of `app.py`. The **Automatic paper trading** toggle starts a roughly 30-second scanner while the browser session is active. It buys simulated **paired YES and NO contracts only** when both displayed asks plus estimated fees total at least 2 cents less than the guaranteed $1 payout per pair. It automatically settles using the official Kalshi result. Maximum simulated cost is $5 per market; starting paper bankroll is $100. SQLite persists trade history on the hosting server.

**For iPhone-only use:** this is source code, not an installed app or live hosted URL. Deploy to a Python/Streamlit-compatible hosting service (with persistent storage) to access it in Safari. Safari sessions can sleep; 24/7 automatic scanning requires a separate always-on background worker. Public hosting requires authentication and storage/security hardening. No real-money API execution is implemented.

**Critical:** paired paper fills assume both quoted asks can be bought simultaneously at displayed prices. Real-world liquidity, timing, fees, slippage and execution risk can erase the theoretical edge. No actual arbitrage is guaranteed.
