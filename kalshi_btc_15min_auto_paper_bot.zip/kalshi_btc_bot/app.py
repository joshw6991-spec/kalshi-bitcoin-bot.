import math, sqlite3, time
from datetime import datetime, timezone
from decimal import Decimal
import requests
import streamlit as st

BASE='https://external-api.kalshi.com/trade-api/v2'
DB='paper_trades.sqlite3'
SERIES='KXBTC15M'
st.set_page_config(page_title='Kalshi BTC 15m Paper Bot',page_icon='₿',layout='wide')

def init():
    with sqlite3.connect(DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY, ticker TEXT, side TEXT, price REAL, qty INTEGER, fee REAL, created TEXT, status TEXT DEFAULT "OPEN", result TEXT, pnl REAL)')

def get(path,params=None):
    r=requests.get(BASE+path,params=params,timeout=12,headers={'User-Agent':'BTC15PaperBot/1.0'})
    r.raise_for_status()
    return r.json()

def fee_estimate(price,qty):
    # General Kalshi taker fee approximation; market-specific fees may differ.
    return math.ceil(100*0.07*qty*price*(1-price))/100

def market_list():
    data=get('/markets',{'series_ticker':SERIES,'status':'open','limit':100})
    return data.get('markets',[])

def dollars(m,field,legacy):
    v=m.get(field)
    if v is not None and v!='': return float(v)
    v=m.get(legacy)
    return float(v)/100 if v is not None else None

def quote(m,side):
    if side=='YES': return dollars(m,'yes_ask_dollars','yes_ask')
    return dollars(m,'no_ask_dollars','no_ask')

def parse_close(m):
    s=m.get('close_time') or m.get('expiration_time')
    if not s:return None
    try:return datetime.fromisoformat(s.replace('Z','+00:00'))
    except ValueError:return None

init()
st.title('₿ Kalshi Bitcoin — 15-Minute Paper Bot')
st.warning('PAPER TRADING ONLY. No API credentials or real-money order placement. Quotes may be delayed; simulated fills are not guaranteed. Do not use as a verified prediction model.')
with st.sidebar:
    st.header('Paper trading settings')
    bankroll=st.number_input('Starting bankroll ($)',min_value=1.0,value=100.0,step=25.0)
    max_trade=st.number_input('Maximum risk per trade ($)',min_value=0.25,value=5.0,step=0.25)
    min_edge=st.slider('Minimum estimated edge (percentage points)',0,30,5)
    st.caption('Your estimated probability is a manual input, not an automated prediction. A real model must be backtested and calibrated.')
    if st.button('Refresh market data'):st.rerun()
    st.caption('Real execution: DISABLED in this version. No live-order endpoint is called.')
try:
    markets=market_list()
except Exception as e:
    st.error(f'Could not retrieve Kalshi markets: {e}')
    markets=[]
now=datetime.now(timezone.utc)
markets=sorted(markets,key=lambda m: abs((parse_close(m)-now).total_seconds()) if parse_close(m) else 1e12)
if markets:
    labels=[f"{m['ticker']} — {m.get('title','')}" for m in markets]
    idx=st.selectbox('Active Bitcoin 15-minute market',range(len(markets)),format_func=lambda i:labels[i])
    m=markets[idx]
    ticker=m['ticker']
    close=parse_close(m)
    remaining=max(0,int((close-now).total_seconds())) if close else None
    yes=quote(m,'YES'); no=quote(m,'NO')
    a,b,c=st.columns(3)
    a.metric('YES ask',f'{yes*100:.1f}¢' if yes is not None else 'Unavailable')
    b.metric('NO ask',f'{no*100:.1f}¢' if no is not None else 'Unavailable')
    c.metric('Time remaining',f'{remaining//60:02}:{remaining%60:02}' if remaining is not None else 'Unknown')
    st.caption(f"Market: {ticker} | Status: {m.get('status','unknown')} | Settlement must use Kalshi's official result, not a spot-price proxy.")
    side=st.radio('Contract to evaluate',['YES','NO'],horizontal=True)
    p=quote(m,side)
    probability=st.slider('Your estimated chance of this side winning (%)',1,99,50)/100
    if p is None or not 0<p<1:
        st.info('No usable ask quote for this side. Trading is blocked.')
    else:
        qty=max(1,int(max_trade/p))
        while qty>0 and qty*p+fee_estimate(p,qty)>max_trade:qty-=1
        fee=fee_estimate(p,qty) if qty else 0
        cost=qty*p+fee
        ev=qty*probability-cost
        edge=probability-cost/qty if qty else -1
        x,y,z=st.columns(3)
        x.metric('Proposed contracts',qty)
        y.metric('Estimated all-in cost',f'${cost:.2f}')
        z.metric('Expected value (your estimate)',f'${ev:+.2f}')
        st.write(f"Break-even win probability: **{100*cost/qty:.2f}%**" if qty else 'Trade size too small.')
        st.write('Signal: **PAPER BUY CANDIDATE**' if qty and edge>=min_edge/100 and remaining is not None and remaining>20 else '**WAIT / NO TRADE**')
        st.caption('Fees use an illustrative general taker-fee formula, rounded up to cents. Actual fees, slippage, liquidity and execution may differ.')
        enabled=bool(qty and edge>=min_edge/100 and remaining is not None and remaining>20)
        if st.button('Record simulated buy at displayed ask',disabled=not enabled):
            with sqlite3.connect(DB) as db:
                db.execute('INSERT INTO trades(ticker,side,price,qty,fee,created) VALUES(?,?,?,?,?,?)',(ticker,side,p,qty,fee,datetime.now(timezone.utc).isoformat()))
            st.success('Simulated trade recorded. No order was sent to Kalshi.')
else:
    st.info('No open KXBTC15M markets were returned. Try refreshing. Market availability and API field formats can change.')
st.subheader('Paper trading journal')
with sqlite3.connect(DB) as db:
    rows=db.execute('SELECT id,ticker,side,price,qty,fee,created,status,result,pnl FROM trades ORDER BY id DESC').fetchall()
    realized=sum(r[9] for r in rows if r[9] is not None)
    reserved=sum(r[3]*r[4]+r[5] for r in rows if r[7]=='OPEN')
    st.metric('Paper bankroll (cash, excluding open positions)',f'${bankroll+realized-reserved:.2f}')
    st.metric('Realized paper P/L',f'${realized:+.2f}')
    if rows:
        st.dataframe([dict(zip(['ID','Ticker','Side','Entry $','Qty','Fee $','Created UTC','Status','Result','P/L $'],r)) for r in rows],hide_index=True,use_container_width=True)
        open_rows=[r for r in rows if r[7]=='OPEN']
        if open_rows:
            st.subheader('Settle a paper position')
            chosen=st.selectbox('Open position ID',[r[0] for r in open_rows])
            result=st.radio('Official Kalshi market result',['YES','NO'],horizontal=True)
            st.caption('Verify the final market result on Kalshi before settling. This is a manual process.')
            if st.button('Settle selected paper position'):
                r=next(r for r in open_rows if r[0]==chosen)
                pnl=(r[4] if r[2]==result else 0)-r[3]*r[4]-r[5]
                with sqlite3.connect(DB) as db:
                    db.execute('UPDATE trades SET status=?,result=?,pnl=? WHERE id=?',('SETTLED',result,pnl,chosen))
                st.rerun()
    else:st.info('No simulated trades yet.')
st.caption('Research tool, not financial advice. A user-supplied probability cannot establish a genuine statistical edge. Paper fills are optimistic because they assume the displayed ask is executable.')
